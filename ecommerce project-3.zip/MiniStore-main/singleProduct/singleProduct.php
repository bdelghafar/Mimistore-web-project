<?php
    require_once("singleproduct.html"); 